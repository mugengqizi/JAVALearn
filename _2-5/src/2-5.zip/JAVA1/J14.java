package JAVA1;

import java.util.Scanner;

public class J14 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        StringBuilder sb1 = new StringBuilder(scanner.nextLine());
        System.out.println(sb1.reverse());
    }
}
