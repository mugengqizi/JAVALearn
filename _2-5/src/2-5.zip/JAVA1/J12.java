package JAVA1;

public class J12 {
    public static void main(String[] args) {
        int a = 1, b = 2;
        System.out.println(sum(a, b));
    }

    public static int sum(int a, int b) {
        return a + b;
    }
}
