package JAVA6;

import java.util.Date;

public class J63 {
    public static void main(String[] args) {
        Date date = new Date();
        System.out.println(date);
    }
}
