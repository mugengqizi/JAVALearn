package JAVA6;

public class J61 {
    public static void main(String[] args) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Hello").append(" World");
        System.out.println(stringBuilder);
    }
}
